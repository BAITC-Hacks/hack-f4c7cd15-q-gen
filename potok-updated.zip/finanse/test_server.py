"""Integration checks for explicit UI routes and existing HTTP contracts."""
import json
import threading
import unittest
from urllib.request import urlopen
from urllib.error import HTTPError
from serve import Handler, ThreadingHTTPServer, ROUTES, ROOT


class QuietHandler(Handler):
    def log_message(self, *args):
        pass


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), QuietHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def get(self, path):
        return urlopen(self.base + path)

    def test_ui_allowlist_and_mime(self):
        for route, (path, mime) in ROUTES.items():
            with self.subTest(route=route), self.get(route) as response:
                self.assertEqual(response.status, 200)
                self.assertEqual(response.headers['Content-Type'], mime)
                self.assertGreater(len(response.read()), 0)
        for route in ['/graph?gid=100000000331309100', '/analytics?view=clusters', '/routes?gid=100000000331309100']:
            with self.get(route) as response:
                self.assertEqual(response.status, 200)
        for route in ['/serve.py', '/database/bank.sqlite3', '/ui/../serve.py', '/node_modules/three/package.json']:
            with self.assertRaises(HTTPError) as error:
                self.get(route)
            self.assertEqual(error.exception.code, 404)

    def test_analytics_controls_and_chain(self):
        with self.get('/api/analytics') as response:
            data = json.load(response)
        self.assertEqual((len(data['nodes']),len(data['edges'])),(2248,3119))
        self.assertTrue(all(isinstance(n['gid'],str) for n in data['nodes']))
        with self.get('/api/controls') as response:
            controls=json.load(response)
        self.assertEqual(controls['passed'],controls['total'])
        with self.get('/api/route-example') as response:
            example=json.load(response)
        with self.get(f"/api/routes?source={example['source']}&target={example['target']}&hops=4&gap=2") as response:
            route=json.load(response)
        self.assertEqual(route['status'],'found')
        self.assertTrue(all(isinstance(s['src'],str) and isinstance(s['dst'],str) for s in route['steps']))

    def test_review_csv_exact_gid(self):
        gid='100000000331309100'
        with self.get('/download/review.csv?gid='+gid) as response:
            self.assertIn('attachment',response.headers['Content-Disposition'])
            csv=response.read().decode('utf-8')
        self.assertIn(gid,csv)
        self.assertIn('priority_evidence',csv)
        with self.assertRaises(HTTPError) as error:
            self.get('/download/review.csv?gid=not-a-client')
        self.assertEqual(error.exception.code,400)

if __name__=='__main__':
    unittest.main()
