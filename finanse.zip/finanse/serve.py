"""Serve only the dashboard and named reports, on localhost."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parent
ROUTES = {'/': ('dashboard.html', 'text/html; charset=utf-8'),
          '/api/analytics': ('out/dashboard.json', 'application/json; charset=utf-8')}
for name in ('nodes_roles', 'clusters', 'top_nodes'):
    ROUTES['/download/' + name + '.csv'] = ('out/' + name + '.csv', 'text/csv; charset=utf-8')


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        route = ROUTES.get(self.path.split('?')[0])
        if not route:
            self.send_error(404)
            return
        path, mime = route
        try:
            data = (ROOT / path).read_bytes()
        except FileNotFoundError:
            self.send_error(503, 'Run python analyze.py first')
            return
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        if self.path.startswith('/download/'):
            self.send_header('Content-Disposition', 'attachment; filename="' + Path(path).name + '"')
        self.end_headers()
        self.wfile.write(data)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    print(f'Open http://127.0.0.1:{args.port}', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
